import type { Access } from 'payload'

export const anyone: Access = () => true
