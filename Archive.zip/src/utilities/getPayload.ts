import { getPayload } from 'payload';
import config from "@payload-config";
export const getPayloadRef = () => getPayload({config})